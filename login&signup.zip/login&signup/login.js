var attempt = 3; // Variable to count number of attempts.
// Below function Executes on click of login button.
function validate(){
var username = document.getElementById("username").value;
var password = document.getElementById("password").value;
if ( username == "aastu" && password == "aastu123"){
window.location = "../FirstPage_homepage/Home.html"; // Redirecting to other page.
alert ("Login successfully");


return false;
}
else{
attempt --;// Decrementing by one.
alert("You have left "+attempt+" attempt;");
// Disabling fields after 3 attempts.
if( attempt == 0){
document.getElementByTagName("input").disabled = true;
return false;
}
}

}
function validate2(){
var email = document.getElementById("email").value;
var password2 = document.getElementById("Password").value;
if (/^([A-Za-z0-9_\-\.])+\@([aastu])+\.(com)$/.test(email)) {
alert("Thank you for your registration.Your username is aastu, passsword asstu123)
  return true;
}


}