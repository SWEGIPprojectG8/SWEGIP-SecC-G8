var attempt = 3; // Variable to count number of attempts.
// Below function Executes on click of login button.
function validate1(){
var username = document.getElementById("username").value;
var password = document.getElementById("password").value;
if ( username == "aastu" && password == "aastu123"){

alert ("Login successfully");
window.location.href="../FirstPage_homepage/Home.html"; // Redirecting to other page.
return false;
}
else{
attempt --;// Decrementing by one.
alert("You have left "+attempt+" attempt;");
// Disabling fields after 3 attempts.
if( attempt == 0){
document.getElementById("username").disabled = true;
document.getElementById("password").disabled = true;
document.getElementById("submit").disabled = true;
return false;
}
}
}
function validate2(){
var email = document.getElementById("email").value;
var password2 = document.getElementById("password2").value;
 var email = document.getElementById('email');
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([aastu])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if (!filter.test(email.value)) {
    alert('Please provide a valid email address');
    email.focus;
return false;}
 if(password2.length < 8) {  
     alert("**Password length must be atleast 8 characters");  
    return false; 
  }  
  
//maximum length of password validation  
  if(password2.length > 15) {  
     alert( "**Password length must not exceed 15 characters");  
     return false;  
  } 




else{
alert("Signed up successfully. your username is aastu password aastu123");
}
}